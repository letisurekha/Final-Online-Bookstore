import React from 'react';
import {Carousel ,Image} from 'react-bootstrap';

const PCarousal= () =>{
    return (
          <Carousel pause='hover'>
                
              <Carousel.Item >
                  <Image src = "/images/Books/41.jpg" alt="books"/>
                  <Image src = "/images/Books/b13.jpg" alt="books"/>
                  <Image src = "/images/Books/b14.jpg" alt="books"/>
                  <Image src = "/images/Books/b15.jpg" alt="books"/>
              </Carousel.Item>

              
              <Carousel.Item >
                  <Image src = "/images/Books/b16.jpg" alt="books"/> 
                  <Image src = "/images/Books/b17.jpg" alt="books"/> 
                  <Image src = "/images/Books/b66.jpg" alt="books"/> 
                 <Image src = "/images/Books/b55.jpg" alt="books"/>
              </Carousel.Item>

              <Carousel.Item >
                  <Image src = "/images/Books/b19.jpg" alt="books"/>
                  <Image src = "/images/Books/b12.jpg" alt="books"/>
                  <Image src = "/images/Books/b88.jpg" alt="books"/>
                  <Image src = "/images/Books/b33.jpg" alt="books"/>
              </Carousel.Item>

              <Carousel.Item >
                  <Image src = "/images/Books/2.jpg" alt="books"/>
                  <Image src = "/images/Books/71.jpg" alt="books"/>
                  <Image src = "/images/Books/4.jpg" alt="books"/>
                  <Image src = "/images/Books/3.jpg" alt="books"/>
                 
              </Carousel.Item>

          </Carousel>
    )
};

export default PCarousal;