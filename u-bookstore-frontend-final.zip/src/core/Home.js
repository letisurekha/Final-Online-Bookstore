import React, { useState, useEffect, Fragment } from 'react';
import { getProducts } from './apiCore';
import Card from './Card';
import Search from './Search';
import PCarousal from './Carousal'

const Home = () => {
    
    const [productsByArrival, setProductsByArrival] = useState([]);
    const [error, setError] = useState(false);

    const loadProductsByArrival = () => {
        getProducts().then(data => {
            console.log(data);
            if(data !== undefined) {
                if (data.error) {
                    setError(data.error);
                } else {
                    setProductsByArrival(data);
                }
            }
        });
    };

    useEffect(() => {
        loadProductsByArrival();
     
    }, []);

    return (
        <div>
            <div className="container-fluid"> 
        
                    <PCarousal/>
                
                    <Search/>
                        
                    <div className="row mb-4">
                        {productsByArrival.map((product, i) => (
                            <div key={i} className="col-4 mb-3">
                                <Card product={product}/>
                            </div>
                        ))}
                    </div>

            </div>
                   <footer className="footer">All right reserved.
                        <Fragment>
                                <a style={{color:"white",fontWeight:"bolder",color:"white",fontSize:20}}
                                    href="https://www.facebook.com" className="fa fa-facebook"
                                ></a>
                                <a
                                    style={{color:"white",fontWeight:"bolder",color:"white",fontSize:20}}
                                    href="https://www.instagram.com" className="fa fa-instagram"
                                >
                                </a>
                        
                            <a
                                    style={{color:"white",fontWeight:"bolder",color:"white",fontSize:20}}
                                    href="https://www.twitter.com" className="fa fa-twitter"
                                >
                                </a>

                        </Fragment>
                    </footer>
           
        </div>
    
    );
};

export default Home;
