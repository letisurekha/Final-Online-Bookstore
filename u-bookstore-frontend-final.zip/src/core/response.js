import React, { useState } from 'react';
import { Link } from 'react-router-dom';


const Response = () => {
  
  

    const ResponsePage = () => (
        <div className="center4">
            <div className="row">
           
                <div className="col">
                        <h2 className="mb-3" style={{color:"black",textAlign:"center",fontFamily:"revert"}}><b><i className="fas fa-book-open">UNICORN</i></b></h2><hr/>
                        <h3 className="mb-3" style={{color:"black",textAlign:"center"}}>Thank you</h3>
                        <p className="mb-3" style={{color:"black",textAlign:"center"}}> We will be in touch with lightening speed and Please Kindly wait for our response. </p>
                        <h3 className="mb-3" style={{color:"black",textAlign:"center"}}> <Link className="btn btn-outline-primary" to="/" style={{borderRadius:5}}>Back to Home</Link> </h3>
                      
                </div>
            </div>  
        </div>
      
    );

    return (
        <div>
           {ResponsePage()}
        </div>
    );
};

export default Response;
