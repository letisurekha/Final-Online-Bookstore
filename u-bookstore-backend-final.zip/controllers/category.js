const Category = require('../models/category');


//create
exports.create = (req, res) =>{
    const category = new Category(req.body);
    category.save((error, data)=>{
        if(error){
            return res.status(400).json({
                error:"Category is not created please try after sometime"
            });
        }
        res.json({data});
    })
};

//find one by id
exports.categoryById = (req, res, next, id) =>{
    Category.findById(id).exec((error, category) =>{
        if(error || !category){
            return res.status(400).json({
                error:"category not found"
            });
        }
        req.category = category
        next();
    });
};



exports.read = (req, res) => {
   return res.json(req.category);
}

//find all
exports.list =(req, res)=>{
    Category.find().exec((error, category) =>{

        if(error){
            return res.status(400).json({
                error:"Categories are not available"
            });
        }
        res.json({category});
    });
};