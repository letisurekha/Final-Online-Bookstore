const mongoose = require('mongoose');

const authorSchema = new mongoose.Schema({
    name: {
        type: String,
        trim: true,
        unique:true
    }
},
  { timestamps: true }
);

module.exports = mongoose.model("Author", authorSchema);