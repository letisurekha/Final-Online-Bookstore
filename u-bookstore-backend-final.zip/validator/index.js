exports.userSignupValidator = (req, res, next) =>{
    req.check('name', 'Name is required').notEmpty()
    req.check('email', 'Email must be between 3 to 32 characters')
   
    .matches((/^[\-0-9a-zA-Z\.\+_]+@[\-0-9a-zA-Z\.\+_]+\.[a-zA-Z]{2,}$/))
     .withMessage(" email should contain letters(a-z), numbers(0-9), and periods (.) are allowed")
     .isLength({
         min:6,
         max:32
     });
     req.check('password', 'Password is required').notEmpty();
     req.check("password")
     .isLength({ min:6 })
     .withMessage("Password must contain atleast 6 characters")
     .matches(/\d/)
     .withMessage("password must contain a number");
     
     //grab the errors
     const errors = req.validationErrors();
     if(errors){
         const firstError = errors.map(error =>error.msg)[0];
         return res.status(400).json({ error: firstError}) ;
     }
     next();
};